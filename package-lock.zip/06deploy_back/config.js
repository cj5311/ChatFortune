module.exports = {
    FRONT_URL: "https://chat-fortune-9z7.pages.dev",
    OPENAI_API: "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",
};


